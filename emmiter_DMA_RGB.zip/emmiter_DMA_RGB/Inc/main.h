
#undef GLOBAL
#ifdef __MAIN_C
#define GLOBAL
#else
#define GLOBAL extern
#endif

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"
#include "b_g474e_dpow1_conf.h"
#include "b_g474e_dpow1.h"

/* Exported types ------------------------------------------------------------*/
typedef enum {
  STATE_LED_COLOR,
  STATE_LED_WHITE,
  MAX_STATE
} STATE_TypeDef;

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported variables ------------------------------------------------------------*/
/* Demo state machine */
GLOBAL __IO  STATE_TypeDef  StateMachine;

GLOBAL HRTIM_HandleTypeDef  HrtimHandle;

/* Exported functions ------------------------------------------------------- */
GLOBAL void Error_Handler(void);
#endif /* __MAIN_H */

