#undef GLOBAL
#ifdef __BLUELEDCOLOR_C
#define GLOBAL
#else
#define GLOBAL extern
#endif

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BLUELEDCOLOR_H
#define __BLUELEDCOLOR_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

extern DAC_HandleTypeDef  DacBlueHandle;

extern void DAC_Blue_Config(void); // blue has DAC1

extern void COMP_Blue_Config(void);

extern void DAC_Blue_DeConfig(void); // blue has DAC1 

extern void COMP_Blue_DeConfig(void);


#ifdef __cplusplus
}
#endif

#endif /* __BLUELEDCOLOR_H */


/******** IOANNIS PAPAGEORGIOU 2022 UOI **********/