#undef GLOBAL
#ifdef __CONTROLER_C
#define GLOBAL
#else
#define GLOBAL extern
#endif

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CONTROLER_H
#define __CONTROLER_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"


GLOBAL void Demo_LedWhite(void);


#ifdef __cplusplus
}
#endif

#endif /* __CONTROLER_H */


/******** IOANNIS PAPAGEORGIOU 2022 UOI **********/