#define __CONTROLER_C


#include "main.h"
#include "defs.h"
#include "redgreenRGB.h"
#include "blueRGB.h"
#include "controlerRGB.h"


typedef enum {
  PHASE_RISING = 0,
  PHASE_FALLING,
  PHASE_OFF,
  MAX_PHASE
}LED_PHASE_TypeDef;

#define  RED   0
#define  GREEN 1
#define  BLUE  2


#define COLOR_STEP                 100 //100
#define GLOBAL_BRIGHTNESS_STEP     100 //100



static __IO int32_t PerMilleRGB[3];   // Range 0 to 1000

static __IO uint32_t  MaxVoltageSenseRGB[3]; 

static const uint32_t hrtim_output[3] = {HRTIM_OUTPUT_TF1, HRTIM_OUTPUT_TE1, HRTIM_OUTPUT_TA1};

static int32_t GlobalBrigthness_1000;  // Range [0 .. 1000]

// Due to color sensitivity, each color must be weighted 
static uint32_t RedWeight;
static uint32_t GreenWeight;
static uint32_t BlueWeight;


DMA_HandleTypeDef    hdma_hrtim_ch1;
DMA_HandleTypeDef    hdma_hrtim_ch5;
DMA_HandleTypeDef    hdma_hrtim_ch3;


// size 32 ****change DMA SIZE = 32 

uint32_t wave_red[32] = {0x20, 0x20, 0xffff, 0xffff, 0xffff, 0xfffff, 0x20, 0x20, 0xffff, 0x20, 0x20, 0xffff, 0xffff, 0xffff, 0x20, 0x20, 0xffff, 0x20, 0x20, 0xffff, 0xffff, 0x20, 0x20, 0xffff, 0xffff, 0xffff, 0xffff, 0xffff, 0x20, 0xffff, 0xffff, 0x20}; // data for red led

uint32_t wave_green[32] = {0xffff, 0xffff, 0x20, 0x20, 0x20, 0xffff, 0xffff, 0xffff, 0xffff, 0x20, 0x20, 0xffff, 0x20, 0xffff, 0xffff, 0x20, 0x20, 0xffff, 0xffff, 0xffff, 0x20, 0xffff, 0xffff, 0xffff, 0x20, 0x20, 0xffff, 0x20, 0x20, 0x20, 0xffff, 0xffff}; // data for green led

uint32_t wave_blue[32] = {0xffff, 0x20, 0xffff, 0x20, 0x20, 0xffff, 0xffff, 0x20, 0xffff, 0x20, 0xffff, 0xffff, 0xffff, 0x20, 0x20, 0xffff, 0x20, 0x20, 0xffff, 0xffff, 0x20, 0xffff, 0xffff, 0x20, 0x20, 0x20, 0xffff, 0x20, 0xffff, 0xffff, 0x20, 0x20}; // data for blue led




// prototypes

static void RGBLed_Init(void);
static void RGBLed_DeInit(void);

static void HRTIM_Config(void);
static void HRTIM_DeConfig(void);




void Demo_LedWhite(void); // white spectrum with rgb combination 

// Gamma correction table: range 0 .. 1000. Gamma factor = 2.2           
// GammaCorrection1000[x] = INT((1000* (x/1000)^(2.2)) + 0.5)            
// the addition of 0.5 is to round up when fractional part is above 0.5  
const uint16_t GammaCorrection1000[1001] = // Range [0 .. 1000]
{
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,   1,   1,   1,
  1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,
  1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   2,   2,   2,   2,   2,   2,   2,
  2,   2,   2,   2,   2,   2,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   3,   4,   4,   4,
  4,   4,   4,   4,   4,   4,   5,   5,   5,   5,   5,   5,   5,   5,   6,   6,   6,   6,   6,   6,
  6,   6,   7,   7,   7,   7,   7,   7,   7,   8,   8,   8,   8,   8,   8,   9,   9,   9,   9,   9,
  9,  10,  10,  10,  10,  10,  10,  11,  11,  11,  11,  11,  12,  12,  12,  12,  12,  13,  13,  13,
 13,  13,  14,  14,  14,  14,  15,  15,  15,  15,  15,  16,  16,  16,  16,  17,  17,  17,  17,  18,
 18,  18,  18,  18,  19,  19,  19,  19,  20,  20,  20,  21,  21,  21,  21,  22,  22,  22,  22,  23,
 23,  23,  24,  24,  24,  24,  25,  25,  25,  26,  26,  26,  27,  27,  27,  27,  28,  28,  28,  29,
 29,  29,  30,  30,  30,  31,  31,  31,  32,  32,  32,  33,  33,  33,  34,  34,  34,  35,  35,  35,
 36,  36,  36,  37,  37,  38,  38,  38,  39,  39,  39,  40,  40,  41,  41,  41,  42,  42,  43,  43,
 43,  44,  44,  44,  45,  45,  46,  46,  47,  47,  47,  48,  48,  49,  49,  49,  50,  50,  51,  51,
 52,  52,  53,  53,  53,  54,  54,  55,  55,  56,  56,  57,  57,  57,  58,  58,  59,  59,  60,  60,
 61,  61,  62,  62,  63,  63,  64,  64,  65,  65,  66,  66,  67,  67,  68,  68,  69,  69,  70,  70,
 71,  71,  72,  72,  73,  73,  74,  74,  75,  75,  76,  77,  77,  78,  78,  79,  79,  80,  80,  81,
 82,  82,  83,  83,  84,  84,  85,  86,  86,  87,  87,  88,  88,  89,  90,  90,  91,  91,  92,  93,
 93,  94,  94,  95,  96,  96,  97,  97,  98,  99,  99, 100, 101, 101, 102, 102, 103, 104, 104, 105,
106, 106, 107, 108, 108, 109, 110, 110, 111, 112, 112, 113, 114, 114, 115, 116, 116, 117, 118, 118,
119, 120, 120, 121, 122, 122, 123, 124, 125, 125, 126, 127, 127, 128, 129, 130, 130, 131, 132, 132,
133, 134, 135, 135, 136, 137, 138, 138, 139, 140, 141, 141, 142, 143, 144, 144, 145, 146, 147, 148,
148, 149, 150, 151, 151, 152, 153, 154, 155, 155, 156, 157, 158, 159, 159, 160, 161, 162, 163, 163,
164, 165, 166, 167, 168, 168, 169, 170, 171, 172, 173, 173, 174, 175, 176, 177, 178, 179, 179, 180,
181, 182, 183, 184, 185, 186, 186, 187, 188, 189, 190, 191, 192, 193, 194, 194, 195, 196, 197, 198,
199, 200, 201, 202, 203, 204, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217,
218, 219, 220, 221, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236,
237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 252, 253, 254, 255, 256, 257,
258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 271, 272, 273, 274, 275, 276, 277, 278,
279, 280, 281, 283, 284, 285, 286, 287, 288, 289, 290, 291, 293, 294, 295, 296, 297, 298, 299, 301,
302, 303, 304, 305, 306, 307, 309, 310, 311, 312, 313, 314, 316, 317, 318, 319, 320, 321, 323, 324,
325, 326, 327, 329, 330, 331, 332, 333, 335, 336, 337, 338, 340, 341, 342, 343, 344, 346, 347, 348,
349, 351, 352, 353, 354, 356, 357, 358, 359, 361, 362, 363, 364, 366, 367, 368, 369, 371, 372, 373,
375, 376, 377, 378, 380, 381, 382, 384, 385, 386, 388, 389, 390, 392, 393, 394, 396, 397, 398, 400,
401, 402, 404, 405, 406, 408, 409, 410, 412, 413, 414, 416, 417, 418, 420, 421, 423, 424, 425, 427,
428, 429, 431, 432, 434, 435, 436, 438, 439, 441, 442, 443, 445, 446, 448, 449, 451, 452, 453, 455,
456, 458, 459, 461, 462, 463, 465, 466, 468, 469, 471, 472, 474, 475, 477, 478, 480, 481, 482, 484,
485, 487, 488, 490, 491, 493, 494, 496, 497, 499, 500, 502, 503, 505, 506, 508, 509, 511, 513, 514,
516, 517, 519, 520, 522, 523, 525, 526, 528, 529, 531, 533, 534, 536, 537, 539, 540, 542, 544, 545,
547, 548, 550, 552, 553, 555, 556, 558, 559, 561, 563, 564, 566, 568, 569, 571, 572, 574, 576, 577,
579, 581, 582, 584, 585, 587, 589, 590, 592, 594, 595, 597, 599, 600, 602, 604, 605, 607, 609, 610,
612, 614, 615, 617, 619, 621, 622, 624, 626, 627, 629, 631, 632, 634, 636, 638, 639, 641, 643, 645,
646, 648, 650, 651, 653, 655, 657, 658, 660, 662, 664, 665, 667, 669, 671, 673, 674, 676, 678, 680,
681, 683, 685, 687, 689, 690, 692, 694, 696, 698, 699, 701, 703, 705, 707, 708, 710, 712, 714, 716,
718, 719, 721, 723, 725, 727, 729, 731, 732, 734, 736, 738, 740, 742, 744, 745, 747, 749, 751, 753,
755, 757, 759, 761, 762, 764, 766, 768, 770, 772, 774, 776, 778, 780, 782, 783, 785, 787, 789, 791,
793, 795, 797, 799, 801, 803, 805, 807, 809, 811, 813, 815, 817, 819, 821, 822, 824, 826, 828, 830,
832, 834, 836, 838, 840, 842, 844, 846, 848, 850, 852, 854, 856, 858, 861, 863, 865, 867, 869, 871,
873, 875, 877, 879, 881, 883, 885, 887, 889, 891, 893, 895, 897, 900, 902, 904, 906, 908, 910, 912,
914, 916, 918, 920, 923, 925, 927, 929, 931, 933, 935, 937, 939, 942, 944, 946, 948, 950, 952, 954,
957, 959, 961, 963, 965, 967, 969, 972, 974, 976, 978, 980, 982, 985, 987, 989, 991, 993, 996, 998,
1000
};



/**
  * @brief  RGB led initialization: DAC, COMP, HRTIM
  * @param  None
  * @retval None
  */
static void RGBLed_Init(void)
{
  // DAC Configuration 
  __HAL_RCC_DAC1_CLK_ENABLE();
  __HAL_RCC_DAC3_CLK_ENABLE();
  DAC_Red_Config(); // red   is on DAC3,        channel 2, triggered by HRTIM F. For debug (on in code) , output goes through OPAMP3 to PB1 (analog mode)
  DAC_Green_Config(); // green is on DAC3,        channel 1, triggered by HRTIM E. For debug (on in code) , output goes through OPAMP1 to PA2 (analog mode)
  DAC_Blue_Config(); // blue  is on DAC1 (slow), channel 1, triggered by HRTIM A. For debug (off by default see warning), output is also connected to PB0 (analog mode)

#ifdef DEBUG_FAST_DAC
  // OPAMP Configuration for DAC3 channel1/2 debug as there is no GPIO output for DAC3 
  OPAMP_Red_Config();
  OPAMP_Green_Config();
#endif

#ifdef DEBUG_SLOW_DAC
  GPIO_InitTypeDef GPIO_InitStructure;
  // Debug DAC1_CH1 on PB0 
  __HAL_RCC_GPIOA_CLK_ENABLE();
  GPIO_InitStructure.Pin  =  GPIO_PIN_4;
  GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);
#endif


  // COMP Configuration 
  COMP_Red_Config();
  COMP_Green_Config();
  COMP_Blue_Config();

  // HRTIM Configuration 
  HRTIM_Config();
}

/**
  * @brief  led deinitialization: DAC, COMP, HRTIM
  * @param  None
  * @retval None
  */
static void RGBLed_DeInit(void)
{
  // HRTIM Deconfiguration 
 HRTIM_DeConfig();

#ifdef DEBUG_FAST_DAC
  // OPAMP Deconfiguration 
  OPAMP_Red_DeConfig();
  OPAMP_Green_DeConfig();

  // Deinit GPIO PA4 
  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);
#endif

  // DAC Deconfiguration 
  DAC_Red_DeConfig();
  DAC_Green_DeConfig();
  DAC_Blue_DeConfig();

  __HAL_RCC_DAC1_CLK_DISABLE();
  __HAL_RCC_DAC3_CLK_DISABLE();

  // COMP Deconfiguration 
  COMP_Red_DeConfig();
  COMP_Green_DeConfig();
  COMP_Blue_DeConfig();

}

void MX_DMA_Init(void)
{

  // DMA controller clock enable 
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  // DMA interrupt init 
  // DMA1_Channel1_IRQn interrupt configuration 
  // for green
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);  //DMA1_Channel1_IRQn
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn); 

  // for green
  HAL_NVIC_SetPriority(DMA1_Channel5_IRQn, 0, 0);  //DMA1_Channel2_IRQn
  HAL_NVIC_EnableIRQ(DMA1_Channel5_IRQn); 

  // for blue
  HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 0);  //DMA1_Channel3_IRQn
  HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn); 

}

void HAL_HRTIM_MspInit(HRTIM_HandleTypeDef * hrtimHandle)
{

  // for red led

    hdma_hrtim_ch1.Instance = DMA1_Channel1; // DMA1_Channel1
    hdma_hrtim_ch1.Init.Request = DMA_REQUEST_HRTIM1_F; //DMA_REQUEST_HRTIM1_F
    hdma_hrtim_ch1.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_hrtim_ch1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_hrtim_ch1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_hrtim_ch1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_hrtim_ch1.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_hrtim_ch1.Init.Mode = DMA_CIRCULAR;
    hdma_hrtim_ch1.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_hrtim_ch1) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(hrtimHandle,hdmaTimerF,hdma_hrtim_ch1); // for timer F


  // for green led

    hdma_hrtim_ch5.Instance = DMA1_Channel5; // DMA1_Channel2
    hdma_hrtim_ch5.Init.Request = DMA_REQUEST_HRTIM1_E; //DMA_REQUEST_HRTIM1_E
    hdma_hrtim_ch5.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_hrtim_ch5.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_hrtim_ch5.Init.MemInc = DMA_MINC_ENABLE;
    hdma_hrtim_ch5.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_hrtim_ch5.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_hrtim_ch5.Init.Mode = DMA_CIRCULAR;
    hdma_hrtim_ch5.Init.Priority = DMA_PRIORITY_HIGH;
    if (HAL_DMA_Init(&hdma_hrtim_ch5) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(hrtimHandle,hdmaTimerE,hdma_hrtim_ch5); // for timer E


  // for green led

    hdma_hrtim_ch3.Instance = DMA1_Channel3; // DMA1_Channel3
    hdma_hrtim_ch3.Init.Request = DMA_REQUEST_HRTIM1_A; //DMA_REQUEST_HRTIM1_A
    hdma_hrtim_ch3.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_hrtim_ch3.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_hrtim_ch3.Init.MemInc = DMA_MINC_ENABLE;
    hdma_hrtim_ch3.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_hrtim_ch3.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_hrtim_ch3.Init.Mode = DMA_CIRCULAR;
    hdma_hrtim_ch3.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_hrtim_ch3) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(hrtimHandle,hdmaTimerA,hdma_hrtim_ch3); // for timer A

}

void HAL_HRTIM_MspDeInit(HRTIM_HandleTypeDef * hrtimHandle)
{
    HAL_DMA_DeInit(hrtimHandle->hdmaTimerF); // for timer F
    HAL_DMA_DeInit(hrtimHandle->hdmaTimerE); // for timer E
    HAL_DMA_DeInit(hrtimHandle->hdmaTimerA); // for timer A
}



void Demo_LedWhite(void)
{
  LED_PHASE_TypeDef Phase = PHASE_RISING;

  // Initialize LedWhite demo 
  RGBLed_Init();

  GlobalBrigthness_1000 = 0;

  // White balance. Could be adjusted to get cool/warm white 
  RedWeight   =  65; // 65
  GreenWeight =  80; //80
  BlueWeight =  50; //50


  // Reset all signal LEDs but keep red led on as we start with rising brightness
  BSP_LED_On(LED_RED);
  BSP_LED_Off(LED_GREEN);
  BSP_LED_Off(LED_BLUE);
  BSP_LED_Off(LED_ORANGE);

  //
  // Start HRTIM waveforms generation                        
  //
  // Set Burst IdleDuration: Global brightness control by HRTIM burst idle duration 
  HrtimHandle.Instance->sCommonRegs.BMCMPR = BURST_PERIOD - ((GlobalBrigthness_1000 * BURST_PERIOD) / 1000);

  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, hrtim_output[RED]) != HAL_OK)
  {
    Error_Handler();
  }
  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, hrtim_output[GREEN]) != HAL_OK)
  {
    Error_Handler();
  }
  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, hrtim_output[BLUE]) != HAL_OK)
  {
    Error_Handler();
  }
  
  //
  // RGB white led automatic dimming                         
  //
  while(1)
  {
      // For small brightness (under threshold), adjust sawtooth level 
      // After threshold, sawtooth level stays at its maximum 
      if (GlobalBrigthness_1000 < BRIGHTNESS_THRESHOLD)
      {
        //
        // Configure Sawtooth waveform generation for all RGB leds 
        //
        MaxVoltageSenseRGB[RED]   = (MAX_DAC_SAW_PEAK * GlobalBrigthness_1000 * RedWeight)   / (100 * BRIGHTNESS_THRESHOLD);
        MaxVoltageSenseRGB[GREEN] = (MAX_DAC_SAW_PEAK * GlobalBrigthness_1000 * GreenWeight)   / (100 * BRIGHTNESS_THRESHOLD);
        MaxVoltageSenseRGB[BLUE] = (MAX_DAC_SAW_PEAK * GlobalBrigthness_1000 * BlueWeight)   / (100 * BRIGHTNESS_THRESHOLD);
        

        // Max current sense should be in the middle of saw tooth slope range 
        HAL_DACEx_SawtoothWaveGenerate(&DacRedHandle, DAC_CHANNEL_2, DAC_SAWTOOTH_POLARITY_DECREMENT, (MaxVoltageSenseRGB[RED]   * 4096) / 3300 ,  FAST_DAC_STEP); //3300
        HAL_DACEx_SawtoothWaveGenerate(&DacGreenHandle, DAC_CHANNEL_1, DAC_SAWTOOTH_POLARITY_DECREMENT, (MaxVoltageSenseRGB[GREEN]   * 4096) / 3300 ,  FAST_DAC_STEP);
        HAL_DACEx_SawtoothWaveGenerate(&DacBlueHandle, DAC_CHANNEL_1, DAC_SAWTOOTH_POLARITY_DECREMENT, (MaxVoltageSenseRGB[BLUE]   * 4096) / 3300 ,  SLOW_DAC_STEP);
         
      }

      // Set Burst IdleDuration: Global brightness control by HRTIM burst idle duration 
      HrtimHandle.Instance->sCommonRegs.BMCMPR = BURST_PERIOD - ((GammaCorrection1000[GlobalBrigthness_1000] * BURST_PERIOD) / 1000);
      

      // Wait between 2 global brightness changes 
      HAL_Delay(5);

      //
      // Automatic increment or decrement brightness depending on rising or falling phase 
      //
      if (Phase == PHASE_RISING) {
        GlobalBrigthness_1000 = GlobalBrigthness_1000 + GLOBAL_BRIGHTNESS_STEP;
      } else {
        GlobalBrigthness_1000 = GlobalBrigthness_1000 - GLOBAL_BRIGHTNESS_STEP;
      }

      if (GlobalBrigthness_1000 > 1000) {
        GlobalBrigthness_1000 = 1000;
        Phase = PHASE_FALLING;
      }

      if (GlobalBrigthness_1000 < 0) {
        GlobalBrigthness_1000 = 0;
        Phase = PHASE_RISING;
      }

      // Update led status 
      if (Phase == PHASE_RISING) {
        // Red led indicates rising phase 
        BSP_LED_Off(LED_BLUE);
        BSP_LED_On(LED_RED);
      } else {
        // Red led indicates falling phase 
        BSP_LED_On(LED_BLUE);
        BSP_LED_Off(LED_RED);
      }
  }

  // Deinitialize LedWhite demo 
  RGBLed_DeInit();

  // Reset all signal LEDs 
  BSP_LED_Off(LED_RED);
  BSP_LED_Off(LED_GREEN);
  BSP_LED_Off(LED_BLUE);
  BSP_LED_Off(LED_ORANGE);
  

  
}

/**
* @brief  HRTIM configuration
* @param  None
* @retval None
*/
static void HRTIM_Config(void)
{
  GPIO_InitTypeDef          GPIO_InitStructure;
  HRTIM_CompareCfgTypeDef   HRTIM_CompareStructureRed; // red
  HRTIM_CompareCfgTypeDef   HRTIM_CompareStructureGreen; // green
  HRTIM_CompareCfgTypeDef   HRTIM_CompareStructureBlue; // blue
  HRTIM_EventCfgTypeDef     HRTIM_ExternalEventStructureRed; // red
  HRTIM_EventCfgTypeDef     HRTIM_ExternalEventStructureGreen; // green
  HRTIM_EventCfgTypeDef     HRTIM_ExternalEventStructureBlue; // blue
  HRTIM_OutputCfgTypeDef    HRTIM_OutputStructureRed; // red
  HRTIM_OutputCfgTypeDef    HRTIM_OutputStructureGreen; // green
  HRTIM_OutputCfgTypeDef    HRTIM_OutputStructureBlue; // blue
  HRTIM_TimeBaseCfgTypeDef  HRTIM_TimeBaseStructureRed; // red 
  HRTIM_TimeBaseCfgTypeDef  HRTIM_TimeBaseStructureGreen; // green
  HRTIM_TimeBaseCfgTypeDef  HRTIM_TimeBaseStructureBlue; // blue
  HRTIM_TimerCfgTypeDef     HRTIM_TimerWaveStructureRed; // red
  HRTIM_TimerCfgTypeDef     HRTIM_TimerWaveStructureGreen; // green
  HRTIM_TimerCfgTypeDef     HRTIM_TimerWaveStructureBlue; // blue
  HRTIM_TimerCtlTypeDef     HRTIM_TimerCtl;
  HRTIM_TimerEventFilteringCfgTypeDef HRTIM_TimerEventFilteringCfg; 
  

  // Enable HRTIM clock 
  __HAL_RCC_HRTIM1_CLK_ENABLE();

  // Enable DMA clock
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();


  HrtimHandle.Instance = HRTIM1;
  HAL_HRTIM_Init(&HrtimHandle);

  // HRTIM initialization startup 
  if(HAL_HRTIM_DLLCalibrationStart(&HrtimHandle, HRTIM_CALIBRATIONRATE_3) != HAL_OK)
  {
    Error_Handler();
  }

  if(HAL_HRTIM_PollForDLLCalibration(&HrtimHandle, HAL_MAX_DELAY) != HAL_OK)
  {
    Error_Handler();
  }

  
  // FROM HERE BEGIN CODE FOR HRTIM_F FOR RED LED
  // Configure HRTIM TIM F                                                       
  // HRTIM output channel configuration : HRTIM_CHF1 (Buck drive red led) / PC6  
  // set on timer period event (HRTIM_OUTPUTSET_TIMPER)  or CMP1 (HRTIM_OUTPUTSET_TIMCMP1)
  // reset from COMP2 
  //
  // GPIOC Peripheral clock enable 
  __HAL_RCC_GPIOC_CLK_ENABLE();
  GPIO_InitStructure.Pin       = GPIO_PIN_6;
  GPIO_InitStructure.Mode      = GPIO_MODE_AF_PP;
  GPIO_InitStructure.Speed     = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStructure.Pull      = GPIO_NOPULL;
  GPIO_InitStructure.Alternate = GPIO_AF13_HRTIM1;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);


  // Configure the output features 
  HRTIM_OutputStructureRed.Polarity              = HRTIM_OUTPUTPOLARITY_HIGH;
  HRTIM_OutputStructureRed.SetSource             = HRTIM_OUTPUTSET_TIMPER | HRTIM_OUTPUTSET_TIMCMP1;
  HRTIM_OutputStructureRed.ResetSource           = HRTIM_OUTPUTRESET_EEV_1 | HRTIM_OUTPUTSET_TIMCMP3; // HRTIM_OUTPUTSET_TIMCMP3
  HRTIM_OutputStructureRed.IdleMode              = HRTIM_OUTPUTIDLEMODE_IDLE;
  HRTIM_OutputStructureRed.IdleLevel             = HRTIM_OUTPUTIDLELEVEL_INACTIVE;
  HRTIM_OutputStructureRed.FaultLevel            = HRTIM_OUTPUTFAULTLEVEL_NONE;
  HRTIM_OutputStructureRed.ChopperModeEnable     = HRTIM_OUTPUTCHOPPERMODE_DISABLED;
  HRTIM_OutputStructureRed.BurstModeEntryDelayed = HRTIM_OUTPUTBURSTMODEENTRY_REGULAR;

  if(HAL_HRTIM_WaveformOutputConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                    HRTIM_OUTPUT_TF1, &HRTIM_OutputStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure HRTIM1_TIMF waveform 
  // this must be general config stuff. Nothing interesting here
  HRTIM_TimerWaveStructureRed.InterruptRequests     = (HRTIM_MASTER_IT_NONE | HRTIM_TIM_IT_NONE); 
  HRTIM_TimerWaveStructureRed.DMARequests           = HRTIM_TIM_DMA_RST; // DMA RESET
  HRTIM_TimerWaveStructureRed.DMASrcAddress         = (int)&wave_red; 
  HRTIM_TimerWaveStructureRed.DMADstAddress         = (int)&(HrtimHandle.Instance->sTimerxRegs[(HRTIM_TIMERINDEX_TIMER_F)].CMP3xR);
  HRTIM_TimerWaveStructureRed.DMASize               = 32; //8
  HRTIM_TimerWaveStructureRed.HalfModeEnable        = HRTIM_HALFMODE_DISABLED; 
  HRTIM_TimerWaveStructureRed.InterleavedMode       = HRTIM_INTERLEAVED_MODE_DISABLED;
  HRTIM_TimerWaveStructureRed.StartOnSync           = HRTIM_SYNCSTART_DISABLED;
  HRTIM_TimerWaveStructureRed.ResetOnSync           = HRTIM_SYNCRESET_DISABLED;
  HRTIM_TimerWaveStructureRed.DACSynchro            = HRTIM_DACSYNC_NONE;
  HRTIM_TimerWaveStructureRed.PreloadEnable         = HRTIM_PRELOAD_DISABLED; 
  HRTIM_TimerWaveStructureRed.UpdateGating          = HRTIM_UPDATEGATING_INDEPENDENT;
  HRTIM_TimerWaveStructureRed.BurstMode             = HRTIM_TIMERBURSTMODE_MAINTAINCLOCK;
  HRTIM_TimerWaveStructureRed.RepetitionUpdate      = HRTIM_UPDATEONREPETITION_DISABLED;
  HRTIM_TimerWaveStructureRed.PushPull              = HRTIM_TIMPUSHPULLMODE_DISABLED;
  HRTIM_TimerWaveStructureRed.FaultEnable           = HRTIM_TIMFAULTENABLE_NONE;
  HRTIM_TimerWaveStructureRed.FaultLock             = HRTIM_TIMFAULTLOCK_READWRITE;
  HRTIM_TimerWaveStructureRed.DeadTimeInsertion     = HRTIM_TIMDEADTIMEINSERTION_DISABLED;
  HRTIM_TimerWaveStructureRed.DelayedProtectionMode = HRTIM_TIMER_F_DELAYEDPROTECTION_DISABLED;
  HRTIM_TimerWaveStructureRed.BalancedIdleAutomaticResume = HRTIM_OUTPUTBIAR_DISABLED;
  HRTIM_TimerWaveStructureRed.UpdateTrigger         = HRTIM_TIMUPDATETRIGGER_TIMER_F;
  HRTIM_TimerWaveStructureRed.ResetTrigger          = HRTIM_TIMRESETTRIGGER_NONE;
  HRTIM_TimerWaveStructureRed.ResetUpdate           = HRTIM_TIMUPDATEONRESET_DISABLED;
  HRTIM_TimerWaveStructureRed.ReSyncUpdate          = HRTIM_TIMERESYNC_UPDATE_UNCONDITIONAL;
  


  if(HAL_HRTIM_WaveformTimerConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, &HRTIM_TimerWaveStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // CMP2 is used to trigger the fast DAC3 (red, green) to step to the next value. I'm not sure exaclty how it is done, but 
  //   the DAC is triggered every HRTIM_CompareStructure.CompareValue counter steps even though the counter is not reset.
  HRTIM_CompareStructureRed.AutoDelayedMode    = HRTIM_AUTODELAYEDMODE_REGULAR;
  HRTIM_CompareStructureRed.AutoDelayedTimeout = 0;
  HRTIM_CompareStructureRed.CompareValue       = (PERIOD/(FAST_DAC_STEP_NB));
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                     HRTIM_COMPAREUNIT_2, &HRTIM_CompareStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // the basic TIMER F counter period setup
  HRTIM_TimeBaseStructureRed.Period            = (PERIOD * 2); // 1 period = 4 �s = 100% time 
  HRTIM_TimeBaseStructureRed.RepetitionCounter = 0x00;// 0x00
  HRTIM_TimeBaseStructureRed.PrescalerRatio    = HRTIM_PRESCALERRATIO_MUL16;
  HRTIM_TimeBaseStructureRed.Mode              = HRTIM_MODE_CONTINUOUS;

  if(HAL_HRTIM_TimeBaseConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, &HRTIM_TimeBaseStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // This is a configuration for the external even to reset the output (PC6) from the analog comparator (COMP2)
  // this in not under timerF in CubeMX
  // Configure External Event Source 1 
  HRTIM_ExternalEventStructureRed.Source      = HRTIM_EEV1SRC_COMP2_OUT;
  HRTIM_ExternalEventStructureRed.Polarity    = HRTIM_EVENTPOLARITY_HIGH;
  HRTIM_ExternalEventStructureRed.Sensitivity = HRTIM_EVENTSENSITIVITY_LEVEL;
  HRTIM_ExternalEventStructureRed.FastMode    = HRTIM_EVENTFASTMODE_ENABLE;
  HRTIM_ExternalEventStructureRed.Filter      = HRTIM_EVENTFILTER_NONE;

  if(HAL_HRTIM_EventConfig(&HrtimHandle, HRTIM_EVENT_1, &HRTIM_ExternalEventStructureRed) != HAL_OK)
  {
    Error_Handler();
  }


  // TIMER F CMP3 is used to ignore (blank in their terminology) any early reset event from the analog comparator 
  //     early in the counter cycle (at the first 1/17th of the 4us period)
  // Compare unit 3 is used to blank COMP event at the beginning of the period 
  // This is to avoid being reset by spurious glitch 

  HRTIM_TimerEventFilteringCfg.Filter = HRTIM_TIMEEVFLT_BLANKINGCMP3;
  HRTIM_TimerEventFilteringCfg.Latch = HRTIM_TIMEVENTLATCH_DISABLED;
  if(HAL_HRTIM_TimerEventFilteringConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, HRTIM_EVENT_1, &HRTIM_TimerEventFilteringCfg) != HAL_OK)
  {
    Error_Handler();
  }
  
  HRTIM_CompareStructureRed.CompareValue       = 0x1500; // 1500 
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                     HRTIM_COMPAREUNIT_3, &HRTIM_CompareStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  
  // CMP1 is used to set the output high. However at the new period it is also set: see HRTIM_OUTPUTSET_TIMPER above
  //     it might be that HRTIM_OUTPUTSET_TIMPER was not required and is a mistake
  //     or a safety feature, if we get a reset event which is not "blanked" by CMP3 above?
  // Compare unit 1 is used to force output of HRTIM few cycles after roll over. 
  // This is to be sure timer output is set despite reset (COMP) event occurring at the very beginning of the period 

  // start producing the output waveform (PC6) which drives the MOSFET
  // Enable the TF1 output 

  HRTIM_CompareStructureRed.CompareValue       = 0x70; //0x70
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                      HRTIM_COMPAREUNIT_1, &HRTIM_CompareStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // Enable the TF1 output 
  if(HAL_HRTIM_WaveformCounterStart_DMA(&HrtimHandle, HRTIM_OUTPUT_TF1) != HAL_OK)
  {
    Error_Handler();
  }
  // DAC trigers: 
  //  reset (start from initial value) - when the counter is reset / rolls over
  //  step - based on CMP2 - set above
  // Configure DAC Reset and Step signal for sawtooth generation 
  HRTIM_TimerCtl.UpDownMode = HRTIM_TIMERUPDOWNMODE_UP;
  HRTIM_TimerCtl.TrigHalf = HRTIM_TIMERTRIGHALF_DISABLED;
  HRTIM_TimerCtl.GreaterCMP3 = HRTIM_TIMERGTCMP3_EQUAL;
  HRTIM_TimerCtl.GreaterCMP1 = HRTIM_TIMERGTCMP1_EQUAL;
                                       //!< the trigger is generated on counter reset or roll-over event 
  HRTIM_TimerCtl.DualChannelDacReset = HRTIM_TIMER_DCDR_COUNTER;
                                      //!< the trigger is generated on compare 2 event 
  HRTIM_TimerCtl.DualChannelDacStep = HRTIM_TIMER_DCDS_CMP2;
  HRTIM_TimerCtl.DualChannelDacEnable = HRTIM_TIMER_DCDE_ENABLED;   // generate both the DAC reset and step trigger events

  if(HAL_HRTIM_TimerDualChannelDacConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, &HRTIM_TimerCtl) != HAL_OK)
  {
    Error_Handler();
  }
  
  // FROM HERE BEGIN CODE FOR HRTIM_E FOR GREEN LED
  //
  // Configure HRTIM TIM E                                                         
  // HRTIM output channel configuration : HRTIM_CHE1 (Buck drive green led) / PC8  
  // These are similar to HRTIM F above. Some structs defined above are re-used here
  //     e.g. the DAC trigger stuff.
  //
  GPIO_InitStructure.Pin       = GPIO_PIN_8;
  GPIO_InitStructure.Alternate = GPIO_AF3_HRTIM1;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);

  // for green 
  // Configure the output features 
  HRTIM_OutputStructureGreen.Polarity              = HRTIM_OUTPUTPOLARITY_HIGH;
  HRTIM_OutputStructureGreen.SetSource             = HRTIM_OUTPUTSET_TIMPER | HRTIM_OUTPUTSET_TIMCMP1;
  HRTIM_OutputStructureGreen.ResetSource           = HRTIM_OUTPUTRESET_EEV_5 | HRTIM_OUTPUTSET_TIMCMP3;  // EEV5 -> COMP3  TIMCMP3
  HRTIM_OutputStructureGreen.IdleMode              = HRTIM_OUTPUTIDLEMODE_IDLE;
  HRTIM_OutputStructureGreen.IdleLevel             = HRTIM_OUTPUTIDLELEVEL_INACTIVE;
  HRTIM_OutputStructureGreen.FaultLevel            = HRTIM_OUTPUTFAULTLEVEL_NONE;
  HRTIM_OutputStructureGreen.ChopperModeEnable     = HRTIM_OUTPUTCHOPPERMODE_DISABLED;
  HRTIM_OutputStructureGreen.BurstModeEntryDelayed = HRTIM_OUTPUTBURSTMODEENTRY_REGULAR;

  // Configure the output features 
  if(HAL_HRTIM_WaveformOutputConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                    HRTIM_OUTPUT_TE1, &HRTIM_OutputStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }


  // Configure HRTIM1_TIM_E waveform 
  // this must be general config stuff. Nothing interesting here
  HRTIM_TimerWaveStructureGreen.InterruptRequests     = (HRTIM_MASTER_IT_NONE | HRTIM_TIM_IT_NONE);
  HRTIM_TimerWaveStructureGreen.DMARequests           = HRTIM_TIM_DMA_RST;
  HRTIM_TimerWaveStructureGreen.DMASrcAddress         = (int)&wave_green;
  HRTIM_TimerWaveStructureGreen.DMADstAddress         = (int)&(HrtimHandle.Instance->sTimerxRegs[(HRTIM_TIMERINDEX_TIMER_E)].CMP3xR);
  HRTIM_TimerWaveStructureGreen.DMASize               = 32;
  HRTIM_TimerWaveStructureGreen.HalfModeEnable        = HRTIM_HALFMODE_DISABLED; 
  HRTIM_TimerWaveStructureGreen.InterleavedMode       = HRTIM_INTERLEAVED_MODE_DISABLED;
  HRTIM_TimerWaveStructureGreen.StartOnSync           = HRTIM_SYNCSTART_DISABLED;
  HRTIM_TimerWaveStructureGreen.ResetOnSync           = HRTIM_SYNCRESET_DISABLED;
  HRTIM_TimerWaveStructureGreen.DACSynchro            = HRTIM_DACSYNC_NONE;
  HRTIM_TimerWaveStructureGreen.PreloadEnable         = HRTIM_PRELOAD_DISABLED;
  HRTIM_TimerWaveStructureGreen.UpdateGating          = HRTIM_UPDATEGATING_INDEPENDENT;
  HRTIM_TimerWaveStructureGreen.BurstMode             = HRTIM_TIMERBURSTMODE_MAINTAINCLOCK;
  HRTIM_TimerWaveStructureGreen.RepetitionUpdate      = HRTIM_UPDATEONREPETITION_DISABLED;
  HRTIM_TimerWaveStructureGreen.PushPull              = HRTIM_TIMPUSHPULLMODE_DISABLED;
  HRTIM_TimerWaveStructureGreen.FaultEnable           = HRTIM_TIMFAULTENABLE_NONE;
  HRTIM_TimerWaveStructureGreen.FaultLock             = HRTIM_TIMFAULTLOCK_READWRITE;
  HRTIM_TimerWaveStructureGreen.DeadTimeInsertion     = HRTIM_TIMDEADTIMEINSERTION_DISABLED;
  HRTIM_TimerWaveStructureGreen.BalancedIdleAutomaticResume = HRTIM_OUTPUTBIAR_DISABLED;
  HRTIM_TimerWaveStructureGreen.ResetTrigger          = HRTIM_TIMRESETTRIGGER_NONE;
  HRTIM_TimerWaveStructureGreen.ResetUpdate           = HRTIM_TIMUPDATEONRESET_DISABLED;
  HRTIM_TimerWaveStructureGreen.ReSyncUpdate          = HRTIM_TIMERESYNC_UPDATE_UNCONDITIONAL;
  HRTIM_TimerWaveStructureGreen.DelayedProtectionMode = HRTIM_TIMER_D_E_DELAYEDPROTECTION_DISABLED;
  HRTIM_TimerWaveStructureGreen.UpdateTrigger         = HRTIM_TIMUPDATETRIGGER_TIMER_E;
  
  

  // Configure HRTIM1_TIME waveform 

  if(HAL_HRTIM_WaveformTimerConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, &HRTIM_TimerWaveStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  // the basic TIMER E counter period setup
  HRTIM_TimeBaseStructureGreen.Period            = (PERIOD * 2); // 1 period = 4 �s = 100% time 
  HRTIM_TimeBaseStructureGreen.RepetitionCounter = 0x00;
  HRTIM_TimeBaseStructureGreen.PrescalerRatio    = HRTIM_PRESCALERRATIO_MUL16;
  HRTIM_TimeBaseStructureGreen.Mode              = HRTIM_MODE_CONTINUOUS;

  HRTIM_CompareStructureGreen.AutoDelayedMode    = HRTIM_AUTODELAYEDMODE_REGULAR;
  HRTIM_CompareStructureGreen.AutoDelayedTimeout = 0;
  HRTIM_CompareStructureGreen.CompareValue       = (PERIOD/(FAST_DAC_STEP_NB));
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                     HRTIM_COMPAREUNIT_2, &HRTIM_CompareStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }


  if(HAL_HRTIM_TimeBaseConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, &HRTIM_TimeBaseStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }


  // Configure External Event Source 5
  HRTIM_ExternalEventStructureGreen.Source      = HRTIM_EEV5SRC_COMP3_OUT;
  if(HAL_HRTIM_EventConfig(&HrtimHandle, HRTIM_EVENT_5, &HRTIM_ExternalEventStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure blanking on COMP event to avoid spurious glitch 
  if(HAL_HRTIM_TimerEventFilteringConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, HRTIM_EVENT_5, &HRTIM_TimerEventFilteringCfg) != HAL_OK)
  {
    Error_Handler();
  }

  // Compare unit 3 is used to blank COMP event at the beginning of the period 
  // This is to avoid being reset by spurious glitch 
  HRTIM_CompareStructureGreen.CompareValue       = 0x30000; // 0x3500  //30.000
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                    HRTIM_COMPAREUNIT_3, &HRTIM_CompareStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }
  

  // Compare unit 1 is used to force output of HRTIM few cycles after roll over. 
  // This is to be sure timer output is set despite reset (COMP) event occurring at the very beginning of the period 
  HRTIM_CompareStructureGreen.CompareValue       = 0x50000; // 0x3200 // 50.000
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                     HRTIM_COMPAREUNIT_1, &HRTIM_CompareStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  // Enable the TE1 output 
  if(HAL_HRTIM_WaveformCounterStart_DMA(&HrtimHandle, HRTIM_OUTPUT_TE1) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure DAC Reset and Step signal for sawtooth generation 
  if(HAL_HRTIM_TimerDualChannelDacConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, &HRTIM_TimerCtl) != HAL_OK)
  {
    Error_Handler();
  }

  // FROM HERE BEGIN CODE FOR HRTIM_A FOR BLUE LED
  //
  // Configure HRTIM TIM A                                                        
  // HRTIM output channel configuration : HRTIM_CHA1 (Buck drive blue led) / PA8  
  //
  // GPIOA Peripheral clock enable 
  __HAL_RCC_GPIOA_CLK_ENABLE();
  GPIO_InitStructure.Pin       = GPIO_PIN_8;
  GPIO_InitStructure.Alternate = GPIO_AF13_HRTIM1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

  HRTIM_OutputStructureBlue.Polarity              = HRTIM_OUTPUTPOLARITY_HIGH;
  HRTIM_OutputStructureBlue.SetSource             = HRTIM_OUTPUTSET_TIMPER | HRTIM_OUTPUTSET_TIMCMP1; // TIMCMP1
  HRTIM_OutputStructureBlue.ResetSource           = HRTIM_OUTPUTRESET_EEV_2 | HRTIM_OUTPUTSET_TIMCMP3; // TIMCMP3
  HRTIM_OutputStructureBlue.IdleMode              = HRTIM_OUTPUTIDLEMODE_IDLE;
  HRTIM_OutputStructureBlue.IdleLevel             = HRTIM_OUTPUTIDLELEVEL_INACTIVE;
  HRTIM_OutputStructureBlue.FaultLevel            = HRTIM_OUTPUTFAULTLEVEL_NONE;
  HRTIM_OutputStructureBlue.ChopperModeEnable     = HRTIM_OUTPUTCHOPPERMODE_DISABLED;
  HRTIM_OutputStructureBlue.BurstModeEntryDelayed = HRTIM_OUTPUTBURSTMODEENTRY_REGULAR;

  // Configure the output features 
  if(HAL_HRTIM_WaveformOutputConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                    HRTIM_OUTPUT_TA1, &HRTIM_OutputStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure HRTIM1_TIM_A waveform 
  // ARIS: this must be general config stuff. Nothing interesting here
  HRTIM_TimerWaveStructureBlue.InterruptRequests     = (HRTIM_MASTER_IT_NONE | HRTIM_TIM_IT_NONE);
  HRTIM_TimerWaveStructureBlue.DMARequests           = HRTIM_TIM_DMA_RST;
  HRTIM_TimerWaveStructureBlue.DMASrcAddress         = (int)&wave_blue;
  HRTIM_TimerWaveStructureBlue.DMADstAddress         = (int)&(HrtimHandle.Instance->sTimerxRegs[(HRTIM_TIMERINDEX_TIMER_A)].CMP3xR);
  HRTIM_TimerWaveStructureBlue.DMASize               = 32; // 8
  HRTIM_TimerWaveStructureBlue.HalfModeEnable        = HRTIM_HALFMODE_DISABLED;
  HRTIM_TimerWaveStructureBlue.InterleavedMode       = HRTIM_INTERLEAVED_MODE_DISABLED;
  HRTIM_TimerWaveStructureBlue.StartOnSync           = HRTIM_SYNCSTART_DISABLED;
  HRTIM_TimerWaveStructureBlue.ResetOnSync           = HRTIM_SYNCRESET_DISABLED;
  HRTIM_TimerWaveStructureBlue.DACSynchro            = HRTIM_DACSYNC_NONE;
  HRTIM_TimerWaveStructureBlue.PreloadEnable         = HRTIM_PRELOAD_DISABLED;
  HRTIM_TimerWaveStructureBlue.UpdateGating          = HRTIM_UPDATEGATING_INDEPENDENT;
  HRTIM_TimerWaveStructureBlue.BurstMode             = HRTIM_TIMERBURSTMODE_MAINTAINCLOCK;
  HRTIM_TimerWaveStructureBlue.RepetitionUpdate      = HRTIM_UPDATEONREPETITION_DISABLED;
  HRTIM_TimerWaveStructureBlue.PushPull              = HRTIM_TIMPUSHPULLMODE_DISABLED;
  HRTIM_TimerWaveStructureBlue.FaultEnable           = HRTIM_TIMFAULTENABLE_NONE;
  HRTIM_TimerWaveStructureBlue.FaultLock             = HRTIM_TIMFAULTLOCK_READWRITE;
  HRTIM_TimerWaveStructureBlue.DeadTimeInsertion     = HRTIM_TIMDEADTIMEINSERTION_DISABLED;
  HRTIM_TimerWaveStructureBlue.BalancedIdleAutomaticResume = HRTIM_OUTPUTBIAR_DISABLED;
  HRTIM_TimerWaveStructureBlue.ResetTrigger          = HRTIM_TIMRESETTRIGGER_NONE;
  HRTIM_TimerWaveStructureBlue.ResetUpdate           = HRTIM_TIMUPDATEONRESET_DISABLED;
  HRTIM_TimerWaveStructureBlue.ReSyncUpdate          = HRTIM_TIMERESYNC_UPDATE_UNCONDITIONAL;


  // Configure HRTIM1_TIMA waveform 
  HRTIM_TimerWaveStructureBlue.DelayedProtectionMode = HRTIM_TIMER_A_B_C_DELAYEDPROTECTION_DISABLED;
  HRTIM_TimerWaveStructureBlue.UpdateTrigger         = HRTIM_TIMUPDATETRIGGER_TIMER_A;
  if(HAL_HRTIM_WaveformTimerConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, &HRTIM_TimerWaveStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // ARIS: the basic TIMER A counter period setup
  HRTIM_TimeBaseStructureBlue.Period            = (PERIOD * 2); /* 1 period = 4 �s = 100% time */
  HRTIM_TimeBaseStructureBlue.RepetitionCounter = 0x00;
  HRTIM_TimeBaseStructureBlue.PrescalerRatio    = HRTIM_PRESCALERRATIO_MUL16;
  HRTIM_TimeBaseStructureBlue.Mode              = HRTIM_MODE_CONTINUOUS;

  HRTIM_CompareStructureBlue.AutoDelayedMode    = HRTIM_AUTODELAYEDMODE_REGULAR;
  HRTIM_CompareStructureBlue.AutoDelayedTimeout = 0;

  HRTIM_CompareStructureBlue.CompareValue       = (PERIOD/(SLOW_DAC_STEP_NB));
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                     HRTIM_COMPAREUNIT_2, &HRTIM_CompareStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  if(HAL_HRTIM_TimeBaseConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, &HRTIM_TimeBaseStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure External Event Source 2 
  HRTIM_ExternalEventStructureBlue.Source      = HRTIM_EEV2SRC_COMP4_OUT; 
  if(HAL_HRTIM_EventConfig(&HrtimHandle, HRTIM_EVENT_2, &HRTIM_ExternalEventStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure blanking on COMP event to avoid spurious glitch 
  if(HAL_HRTIM_TimerEventFilteringConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, HRTIM_EVENT_2, &HRTIM_TimerEventFilteringCfg) != HAL_OK)
  {
    Error_Handler();
  }

  // Compare unit 3 is used to blank COMP event at the beginning of the period 
  // This is to avoid being reset by spurious glitch 
  
  HRTIM_CompareStructureBlue.CompareValue       = 0x3000; // 0x3000
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                    HRTIM_COMPAREUNIT_3, &HRTIM_CompareStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // Compare unit 1 is used to force output of HRTIM few cycles after roll over. 
  // This is to be sure timer output is set despite reset (COMP) event occurring at the very beginning of the period 
  HRTIM_CompareStructureBlue.CompareValue       = 0x70; // 0x200 //70 //1200
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                     HRTIM_COMPAREUNIT_1, &HRTIM_CompareStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }
  
  // Enable the TA1 output 
  if(HAL_HRTIM_WaveformCounterStart_DMA(&HrtimHandle, HRTIM_OUTPUT_TA1) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure DAC Reset and Step signal for sawtooth generation 
  if(HAL_HRTIM_TimerDualChannelDacConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, &HRTIM_TimerCtl) != HAL_OK)
  {
    Error_Handler();
  }

  // ---------------------------  these are for all HRTIM timers  -------------------------------------------
  // Start all slaves in one shot so that theyre are all synchronised 

  if(HAL_HRTIM_WaveformCounterStart_DMA(&HrtimHandle, HRTIM_TIMERID_TIMER_E | HRTIM_TIMERID_TIMER_F | HRTIM_TIMERID_TIMER_A) != HAL_OK)
  {
    Error_Handler();
  }

  // Select Burst Trigger 
  if(HAL_HRTIM_BurstModeSoftwareTrigger(&HrtimHandle) != HAL_OK)
  {
    Error_Handler();
  }

}


static void HRTIM_DeConfig(void)
{
  // BUCK LED is OFF 
  HrtimHandle.Instance->sCommonRegs.BMCMPR = BURST_PERIOD;
  HAL_Delay(10);

  // Stop HRTIM A1 waveform generation
  if(HAL_HRTIM_WaveformOutputStop(&HrtimHandle,  HRTIM_OUTPUT_TA1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_HRTIM_WaveformCounterStop_DMA(&HrtimHandle,  HRTIM_TIMERID_TIMER_A);

  // Stop HRTIM E1 waveform generation
  if(HAL_HRTIM_WaveformOutputStop(&HrtimHandle,  HRTIM_OUTPUT_TE1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_HRTIM_WaveformCounterStop_DMA(&HrtimHandle,  HRTIM_TIMERID_TIMER_E);

  // Stop HRTIM F1 waveform generation 
  if(HAL_HRTIM_WaveformOutputStop(&HrtimHandle,  HRTIM_OUTPUT_TF1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_HRTIM_WaveformCounterStop_DMA(&HrtimHandle,  HRTIM_TIMERID_TIMER_F);

  // Stop burst mode and deinitialize HRTIM 
  HAL_HRTIM_BurstModeCtl(&HrtimHandle, HRTIM_BURSTMODECTL_DISABLED);
  HAL_HRTIM_DeInit(&HrtimHandle);
  __HAL_RCC_HRTIM1_CLK_DISABLE();
  __HAL_RCC_HRTIM1_FORCE_RESET();
  HAL_Delay(1);
  __HAL_RCC_HRTIM1_RELEASE_RESET();

  // Deinit GPIO 
  HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6);
  HAL_GPIO_DeInit(GPIOC, GPIO_PIN_8);
  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_8);
}

/******* END OF CONTROLER ************/
/******** IOANNIS PAPAGEORGIOU 2022 UOI **********/