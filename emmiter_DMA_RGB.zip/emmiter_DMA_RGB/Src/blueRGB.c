
// blue led

#define __BLUELEDCOLOR_C

#include "controlerRGB.h"
#include "blueRGB.h"
#include "defs.h"


static COMP_HandleTypeDef CompBlueHandle;

DAC_HandleTypeDef DacBlueHandle; // that variable pass with blueRGB.h to controler.c


// prototypes

void DAC_Blue_Config(void);

void COMP_Blue_Config(void);

void DAC_Blue_DeConfig(void); // Blue use DAC1 alone 

void COMP_Blue_DeConfig(void);



/**
* @brief  DAC configuration for Blue color
* @param  None
* @retval None
*/
void DAC_Blue_Config(void)
{
  // DAC1 channel1 is used for blue led 
  DAC_ChannelConfTypeDef DAC_ConfigStructure = {0};

  // DAC1 is a slow DAC. Up to 1M samples per seconds. 
  // Nevertheless it is possible to have better performances under conditions to see AN4566 
  DacBlueHandle.Instance = DAC1;

  // DAC Init 
  if(HAL_DAC_Init(&DacBlueHandle) != HAL_OK)
  {
    Error_Handler();
  }

  // Fill DAC ConfigStructure 
  // Sawtooth waveform generation will be triggerred by HRTIM A 
  DAC_ConfigStructure.DAC_Trigger      = DAC_TRIGGER_HRTIM_RST_TRG1;  // TRG1 correspond to HRTIM A
  DAC_ConfigStructure.DAC_Trigger2     = DAC_TRIGGER_HRTIM_STEP_TRG1;
#ifdef DEBUG_SLOW_DAC
  DAC_ConfigStructure.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  DAC_ConfigStructure.DAC_ConnectOnChipPeripheral      = DAC_CHIPCONNECT_BOTH;
#else
  DAC_ConfigStructure.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;
  DAC_ConfigStructure.DAC_ConnectOnChipPeripheral      = DAC_CHIPCONNECT_INTERNAL;
#endif
  DAC_ConfigStructure.DAC_SampleAndHold      = DAC_SAMPLEANDHOLD_DISABLE;
  if(HAL_DAC_ConfigChannel(&DacBlueHandle, &DAC_ConfigStructure, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  // Start Sawtooth waveform generation 
  HAL_DACEx_SawtoothWaveGenerate(&DacBlueHandle, DAC_CHANNEL_1, DAC_SAWTOOTH_POLARITY_DECREMENT, 0, SLOW_DAC_STEP);
  if(HAL_DAC_Start(&DacBlueHandle, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
* @brief  DAC deconfiguration for Blue color
* @param  None
* @retval None
*/
void DAC_Blue_DeConfig(void)
{
  // Deconfigure DAC1 channel1 
  HAL_DAC_Stop(&DacBlueHandle, DAC_CHANNEL_1);
  HAL_DAC_DeInit(&DacBlueHandle);
}


/**
* @brief  COMP configuration for Blue color
* @param  None
* @retval None
*/
void COMP_Blue_Config(void)
{
  // COMP4 is used for blue led sense 

  GPIO_InitTypeDef GPIO_InitStructure;

  // GPIOB Peripheral clock enable 
  __HAL_RCC_GPIOB_CLK_ENABLE();

  // Configure PB0 in analog mode: PB0 is connected to COMP4 non inverting input 
  GPIO_InitStructure.Pin  =  GPIO_PIN_0;
  GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStructure);

  //  COMP4 deinitialize 
  __HAL_RCC_SYSCFG_CLK_ENABLE();
  CompBlueHandle.Instance = COMP4;

  // COMP4 config 
  CompBlueHandle.Init.InputMinus        = COMP_INPUT_MINUS_DAC1_CH1;
  CompBlueHandle.Init.InputPlus         = COMP_INPUT_PLUS_IO1;
  CompBlueHandle.Init.OutputPol         = COMP_OUTPUTPOL_NONINVERTED;
  CompBlueHandle.Init.Hysteresis        = COMP_HYSTERESIS_NONE;
  CompBlueHandle.Init.BlankingSrce      = COMP_BLANKINGSRC_NONE;
  CompBlueHandle.Init.TriggerMode       = COMP_TRIGGERMODE_NONE;
  if(HAL_COMP_Init(&CompBlueHandle) != HAL_OK)
  {
    Error_Handler();
  }

  // Enable COMP4 
  if(HAL_COMP_Start(&CompBlueHandle) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
* @brief  COMP deconfiguration for Blue color
* @param  None
* @retval None
*/
void COMP_Blue_DeConfig(void)
{
  // Deconfigure COMP 
  HAL_COMP_Stop(&CompBlueHandle);
  HAL_COMP_DeInit(&CompBlueHandle);
}

/******* END OF BLUE RGB ************/
/******** IOANNIS PAPAGEORGIOU 2022 UOI **********/




