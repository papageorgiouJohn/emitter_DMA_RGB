
// led and green leds  

#define __REDGREENLEDCOLOR_C

#include "controlerRGB.h"
#include "redgreenRGB.h"
#include "defs.h"


DAC_HandleTypeDef  DacRedHandle; // that variable pass with redgreenRGB.h to controler.c
DAC_HandleTypeDef  DacGreenHandle; // that variable pass with redgreenRGB.h to controler.c


static COMP_HandleTypeDef CompRedHandle;
static COMP_HandleTypeDef CompGreenHandle;


static OPAMP_HandleTypeDef OpampRedHandle;
static OPAMP_HandleTypeDef OpampGreenHandle;


// prototypes

void DAC_Red_Config(void);
void DAC_Green_Config(void);


void COMP_Red_Config(void);
void COMP_Green_Config(void);


void DAC_Red_DeConfig(void);
void DAC_Green_DeConfig(void); // red and green shares DAC3 , DAC3 has 2 channels and must work together for this reason  

void COMP_Red_DeConfig(void);
void COMP_Green_DeConfig(void);



#ifdef DEBUG_FAST_DAC
void OPAMP_Red_Config(void);
void OPAMP_Green_Config(void);
void OPAMP_Red_DeConfig(void);
void OPAMP_Green_DeConfig(void);
#endif


/**
* @brief  DAC configuration for Red color
* @param  None
* @retval None
*/
void DAC_Red_Config(void)
{
  // DAC3 channel2 is used for red led 
  DAC_ChannelConfTypeDef DAC_ConfigStructure = {0};

  // DAC3 deinitialize 
  // DAC3 is a fast DAC. Up to 15M samples per seconds 
  DacRedHandle.Instance = DAC3;

  // DAC Init 
  if(HAL_DAC_Init(&DacRedHandle) != HAL_OK)
  {
    Error_Handler();
  }

  // Fill DAC ConfigStructure 
  // Sawtooth waveform generation will be triggerred by HRTIM F 
  DAC_ConfigStructure.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;
  DAC_ConfigStructure.DAC_Trigger      = DAC_TRIGGER_HRTIM_RST_TRG6;  // TRG6 correspond to HRTIM F
  DAC_ConfigStructure.DAC_Trigger2     = DAC_TRIGGER_HRTIM_STEP_TRG6;
  DAC_ConfigStructure.DAC_ConnectOnChipPeripheral      = DAC_CHIPCONNECT_INTERNAL;
  DAC_ConfigStructure.DAC_SampleAndHold      = DAC_SAMPLEANDHOLD_DISABLE;
  if(HAL_DAC_ConfigChannel(&DacRedHandle, &DAC_ConfigStructure, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }

  // Start Sawtooth waveform generation 
  HAL_DACEx_SawtoothWaveGenerate(&DacRedHandle, DAC_CHANNEL_2, DAC_SAWTOOTH_POLARITY_DECREMENT, 0, FAST_DAC_STEP);
  if(HAL_DAC_Start(&DacRedHandle, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  
}

void DAC_Green_Config(void)
{
  // DAC3 channel1 is used for green led 
  DAC_ChannelConfTypeDef DAC_ConfigStructure = {0};

  // DAC3 deinitialize 
  // DAC3 is a fast DAC. Up to 15M samples per seconds 
  DacGreenHandle.Instance = DAC3;

  // DAC Init 
  if(HAL_DAC_Init(&DacGreenHandle) != HAL_OK)
  {
    Error_Handler();
  }

  // Fill DAC ConfigStructure 
  // Sawtooth waveform generation will be triggerred by HRTIM E 
  DAC_ConfigStructure.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;
  DAC_ConfigStructure.DAC_Trigger      = DAC_TRIGGER_HRTIM_RST_TRG5;  // TRG5 correspond to HRTIM E
  DAC_ConfigStructure.DAC_Trigger2     = DAC_TRIGGER_HRTIM_STEP_TRG5;
  DAC_ConfigStructure.DAC_ConnectOnChipPeripheral      = DAC_CHIPCONNECT_INTERNAL;
  DAC_ConfigStructure.DAC_SampleAndHold      = DAC_SAMPLEANDHOLD_DISABLE;
  if(HAL_DAC_ConfigChannel(&DacGreenHandle, &DAC_ConfigStructure, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  // Start Sawtooth waveform generation 
  HAL_DACEx_SawtoothWaveGenerate(&DacGreenHandle, DAC_CHANNEL_1, DAC_SAWTOOTH_POLARITY_DECREMENT, 0, FAST_DAC_STEP);
  if(HAL_DAC_Start(&DacGreenHandle, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
* @brief  DAC deconfiguration for Red color
* @param  None
* @retval None
*/
void DAC_Red_DeConfig(void)
{
  // Deconfigure DAC3 channel2 
  HAL_DAC_Stop(&DacRedHandle, DAC_CHANNEL_2);
  HAL_DAC_DeInit(&DacRedHandle);
}

/**
* @brief  DAC deconfiguration for Green color
* @param  None
* @retval None
*/
void DAC_Green_DeConfig(void)
{
  // Deconfigure DAC3 channel1 
  HAL_DAC_Stop(&DacGreenHandle, DAC_CHANNEL_1);
  HAL_DAC_DeInit(&DacGreenHandle);
}



/**
* @brief  COMP configuration for Red color
* @param  None
* @retval None
*/
void COMP_Red_Config(void)
{
  // COMP2 is used for red led sense 

  GPIO_InitTypeDef GPIO_InitStructure;

  // GPIOB Peripheral clock enable 
  __HAL_RCC_GPIOA_CLK_ENABLE();

  // Configure PA7 in analog mode: PA7 is connected to COMP2 non inverting input 
  GPIO_InitStructure.Pin  =  GPIO_PIN_7;
  GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

  //  COMP2 deinitialize 
  __HAL_RCC_SYSCFG_CLK_ENABLE();
  CompRedHandle.Instance = COMP2;

  // COMP2 config 
  CompRedHandle.Init.InputMinus        = COMP_INPUT_MINUS_DAC3_CH2;
  CompRedHandle.Init.InputPlus         = COMP_INPUT_PLUS_IO1;
  CompRedHandle.Init.OutputPol         = COMP_OUTPUTPOL_NONINVERTED;
  CompRedHandle.Init.Hysteresis        = COMP_HYSTERESIS_NONE;
  CompRedHandle.Init.BlankingSrce      = COMP_BLANKINGSRC_NONE;
  CompRedHandle.Init.TriggerMode       = COMP_TRIGGERMODE_NONE;
  if(HAL_COMP_Init(&CompRedHandle) != HAL_OK)
  {
    Error_Handler();
  }

  // Enable COMP2 
  if(HAL_COMP_Start(&CompRedHandle) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
* @brief  COMP configuration for Green color
* @param  None
* @retval None
*/
void COMP_Green_Config(void)
{
  // COMP3 is used for green led sense 

  GPIO_InitTypeDef GPIO_InitStructure;

  // GPIOB Peripheral clock enable 
  __HAL_RCC_GPIOA_CLK_ENABLE();

  // Configure PA0 in analog mode: PA0 is connected to COMP3 non inverting input 
  GPIO_InitStructure.Pin  =  GPIO_PIN_0;
  GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

  //  COMP3 deinitialize 
  __HAL_RCC_SYSCFG_CLK_ENABLE();
  CompGreenHandle.Instance = COMP3;

  // COMP3 config 
  CompGreenHandle.Init.InputMinus        = COMP_INPUT_MINUS_DAC3_CH1;
  CompGreenHandle.Init.InputPlus         = COMP_INPUT_PLUS_IO1;
  CompGreenHandle.Init.OutputPol         = COMP_OUTPUTPOL_NONINVERTED;
  CompGreenHandle.Init.Hysteresis        = COMP_HYSTERESIS_NONE;
  CompGreenHandle.Init.BlankingSrce      = COMP_BLANKINGSRC_NONE;
  CompGreenHandle.Init.TriggerMode       = COMP_TRIGGERMODE_NONE;
  if(HAL_COMP_Init(&CompGreenHandle) != HAL_OK)
  {
    Error_Handler();
  }

  // Enable COMP3 
  if(HAL_COMP_Start(&CompGreenHandle) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
* @brief  COMP deconfiguration for Red color
* @param  None
* @retval None
*/
void COMP_Red_DeConfig(void)
{
  // Deconfigure COMP 
  HAL_COMP_Stop(&CompRedHandle);
  HAL_COMP_DeInit(&CompRedHandle);
}

/**
* @brief  COMP deconfiguration for Green color
* @param  None
* @retval None
*/
void COMP_Green_DeConfig(void)
{
  // Deconfigure COMP 
  HAL_COMP_Stop(&CompGreenHandle);
  HAL_COMP_DeInit(&CompGreenHandle);
}



#ifdef DEBUG_FAST_DAC
/**
* @brief  OPAMP configuration: follower mode.
*         Used for debug purpose to be able to view DAC output on GPIO
*         Warning: PB1 used for debug of red DAC (through OPAMP) is already used for Orange led
* @param  None
* @retval None
*/
void OPAMP_Red_Config(void)
{
  GPIO_InitTypeDef       GPIO_InitStructure;

  // OPAMP output configuration :  PB1 
  // GPIOB Peripheral clock enable 
  __HAL_RCC_GPIOB_CLK_ENABLE();
  GPIO_InitStructure.Pin       = GPIO_PIN_1;
  GPIO_InitStructure.Mode      = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Speed     = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStructure.Pull      = GPIO_NOPULL;
  GPIO_InitStructure.Alternate = 0x0;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStructure);

  // Enable OPAMP clock 
  __HAL_RCC_SYSCFG_CLK_ENABLE();

  // Configure OPAMP in follower mode to view DAC output on GPIO 
  OpampRedHandle.Instance = OPAMP3;
  OpampRedHandle.Init.PowerMode = OPAMP_POWERMODE_HIGHSPEED;
  OpampRedHandle.Init.Mode = OPAMP_FOLLOWER_MODE;
  OpampRedHandle.Init.NonInvertingInput = OPAMP_NONINVERTINGINPUT_DAC ;
  OpampRedHandle.Init.InvertingInput = 0x0;
  OpampRedHandle.Init.InternalOutput = ENABLE;
  OpampRedHandle.Init.TimerControlledMuxmode = OPAMP_TIMERCONTROLLEDMUXMODE_DISABLE;
  OpampRedHandle.Init.InvertingInputSecondary = 0;
  OpampRedHandle.Init.NonInvertingInputSecondary = 0;
  OpampRedHandle.Init.PgaConnect = 0;
  OpampRedHandle.Init.PgaGain = 0;
  OpampRedHandle.Init.UserTrimming = OPAMP_TRIMMING_USER;
  OpampRedHandle.Init.TrimmingValueP = 0;
  OpampRedHandle.Init.TrimmingValueN = 0;
  HAL_OPAMP_Init(&OpampRedHandle);

  // Calibrate OPAMP 
  HAL_OPAMP_SelfCalibrate(&OpampRedHandle);

// To avoid blink of orange led during opamp calibration, the output is enabled only after calbration 
  OpampRedHandle.Init.InternalOutput = DISABLE;
  HAL_OPAMP_Init(&OpampRedHandle);

  // Start OPAMP 
  HAL_OPAMP_Start(&OpampRedHandle);
}

/**
* @brief  OPAMP configuration: follower mode.
*         Used for debug purpose to be able to view DAC output on GPIO
* @param  None
* @retval None
*/
void OPAMP_Green_Config(void)
{
  GPIO_InitTypeDef       GPIO_InitStructure;

  // Enable OPAMP clock 
  __HAL_RCC_SYSCFG_CLK_ENABLE();

  // OPAMP output configuration :  PA2 
  // GPIOA Peripheral clock enable 
  __HAL_RCC_GPIOA_CLK_ENABLE();
  GPIO_InitStructure.Pin       = GPIO_PIN_2;
  GPIO_InitStructure.Mode      = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Speed     = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStructure.Pull      = GPIO_NOPULL;
  GPIO_InitStructure.Alternate = 0x0;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

  // Configure OPAMP in follower mode to view DAC output on GPIO 
  OpampGreenHandle.Instance = OPAMP1;
  OpampGreenHandle.Init.PowerMode = OPAMP_POWERMODE_HIGHSPEED;
  OpampGreenHandle.Init.Mode = OPAMP_FOLLOWER_MODE;
  OpampGreenHandle.Init.NonInvertingInput = OPAMP_NONINVERTINGINPUT_DAC ;
  OpampGreenHandle.Init.InvertingInput = 0x0;
  OpampGreenHandle.Init.InternalOutput = DISABLE;
  OpampGreenHandle.Init.TimerControlledMuxmode = OPAMP_TIMERCONTROLLEDMUXMODE_DISABLE;
  OpampGreenHandle.Init.InvertingInputSecondary = 0;
  OpampGreenHandle.Init.NonInvertingInputSecondary = 0;
  OpampGreenHandle.Init.PgaConnect = 0;
  OpampGreenHandle.Init.PgaGain = 0;
  OpampGreenHandle.Init.UserTrimming = OPAMP_TRIMMING_USER;
  OpampGreenHandle.Init.TrimmingValueP = 0;
  OpampGreenHandle.Init.TrimmingValueN = 0;
  HAL_OPAMP_Init(&OpampGreenHandle);

  // Calibrate OPAMP 
  HAL_OPAMP_SelfCalibrate(&OpampGreenHandle);

  // Start OPAMP 
  HAL_OPAMP_Start(&OpampGreenHandle);
}

/**
* @brief  OPAMP deconfiguration.
* @param  None
* @retval None
*/
void OPAMP_Red_DeConfig(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  HAL_OPAMP_Stop(&OpampRedHandle);
  HAL_OPAMP_DeInit(&OpampRedHandle);

  // Deinit GPIO PB1 
  HAL_GPIO_DeInit(GPIOB, GPIO_PIN_1);

  // Restore LED orange configuration 
  GPIO_InitStructure.Pin       = GPIO_PIN_1;
  GPIO_InitStructure.Mode      = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStructure.Speed     = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStructure.Pull      = GPIO_NOPULL;
  GPIO_InitStructure.Alternate = 0x0;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStructure);
}

/**
* @brief  OPAMP deconfiguration.
* @param  None
* @retval None
*/
void OPAMP_Green_DeConfig(void)
{
  HAL_OPAMP_Stop(&OpampGreenHandle);
  HAL_OPAMP_DeInit(&OpampGreenHandle);

  // Deinit GPIO PA2 
  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_2);
}
#endif

/******* END OF REDGREENRGB ************/
/******** IOANNIS PAPAGEORGIOU 2022 UOI **********/


